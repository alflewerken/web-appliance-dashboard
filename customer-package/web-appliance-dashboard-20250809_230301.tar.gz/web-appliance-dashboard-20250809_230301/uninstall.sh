#!/bin/bash
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}=== Web Appliance Dashboard Uninstaller ===${NC}"
echo ""

# Detect Docker Compose command
COMPOSE_COMMAND=""
if command -v docker-compose &> /dev/null; then
    COMPOSE_COMMAND="docker-compose"
elif docker compose version &> /dev/null 2>&1; then
    COMPOSE_COMMAND="docker compose"
else
    echo -e "${RED}❌ Docker Compose is not found!${NC}"
    exit 1
fi

read -p "⚠️  This will stop and remove all containers. Continue? [y/N] " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 0
fi

echo "🛑 Stopping services..."
$COMPOSE_COMMAND down

read -p "⚠️  Remove all data volumes? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🗑️  Removing volumes..."
    $COMPOSE_COMMAND down -v
fi

echo -e "${GREEN}✅ Uninstall complete${NC}"
