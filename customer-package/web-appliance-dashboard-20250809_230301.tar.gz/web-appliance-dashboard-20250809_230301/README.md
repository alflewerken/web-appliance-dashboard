# Web Appliance Dashboard - Customer Package

## Quick Start

1. Extract the package
2. Run the installer:
   ```bash
   ./install.sh
   ```
3. Access the dashboard:
   - http://localhost
   - http://[your-hostname]

Default credentials:
- Username: `admin`
- Password: `admin123`

## Requirements

- Docker Engine 20.10+
- Docker Compose 2.0+ (or docker-compose 1.29+)
- Ports 80 and 443 available (configurable in .env)

## Commands

- **Start services**: `docker compose up -d`
- **Stop services**: `docker compose down`
- **View logs**: `docker compose logs -f`
- **Restart a service**: `docker compose restart [service]`
- **Troubleshoot**: `./troubleshoot.sh`

## Configuration

Edit `.env` file to customize:
- Database passwords
- Port numbers
- CORS origins
- Admin credentials

## Services Included

- **Frontend**: React-based web interface
- **Backend**: Node.js API server
- **Database**: MariaDB
- **Terminal**: Web-based terminal (Wetty)
- **Remote Desktop**: Guacamole (VNC/RDP)
- **Reverse Proxy**: Nginx

## Troubleshooting

1. **Login fails**: 
   - Check if database is running: `docker compose ps`
   - Check backend logs: `docker compose logs backend`
   - Run `./troubleshoot.sh` for diagnostics

2. **CORS errors**:
   - Check browser console for the exact origin
   - Verify ALLOWED_ORIGINS in `.env` includes your access URL
   - Restart backend after changes: `docker compose restart backend`

3. **Port conflicts**:
   - Edit `.env` and change HTTP_PORT/HTTPS_PORT
   - Restart services

4. **Services not starting**:
   - Run `./troubleshoot.sh` for diagnostics
   - Check individual service logs

## Uninstall

To remove the installation:
```bash
./uninstall.sh
```

## Support

For issues, check:
1. Service logs: `docker compose logs [service]`
2. Troubleshooting script: `./troubleshoot.sh`
3. Documentation: https://github.com/alflewerken/web-appliance-dashboard

## Security Notes

- Default installation uses self-signed SSL certificates
- Change the admin password after first login
- Review and update security keys in `.env` for production use
- The included GitHub token is for pulling private Docker images only

## Version

This is v2.0 of the customer package with:
- Full database schema compatibility
- Automatic CORS configuration
- Robust error handling
- Built-in troubleshooting tools
