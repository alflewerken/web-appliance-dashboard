#!/bin/bash
set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}=== Web Appliance Dashboard Installer ===${NC}"
echo ""

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker is not installed!${NC}"
    echo "Please install Docker first: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check Docker Compose
COMPOSE_COMMAND=""
if command -v docker-compose &> /dev/null; then
    COMPOSE_COMMAND="docker-compose"
elif docker compose version &> /dev/null 2>&1; then
    COMPOSE_COMMAND="docker compose"
else
    echo -e "${RED}❌ Docker Compose is not installed!${NC}"
    exit 1
fi

echo "✅ Using Docker Compose command: $COMPOSE_COMMAND"

# Detect hostname and update CORS
HOSTNAME=$(hostname)
HOSTNAME_FQDN=$(hostname -f 2>/dev/null || hostname)

echo "🌐 Detected hostname: $HOSTNAME"
echo "🌐 Detected FQDN: $HOSTNAME_FQDN"

# Update ALLOWED_ORIGINS in .env - include both lowercase and original case
echo "📝 Updating CORS configuration..."
HOSTNAME_LOWER=$(echo "$HOSTNAME" | tr '[:upper:]' '[:lower:]')
HOSTNAME_FQDN_LOWER=$(echo "$HOSTNAME_FQDN" | tr '[:upper:]' '[:lower:]')

# Build ALLOWED_ORIGINS with both cases
ALLOWED_ORIGINS="http://localhost,https://localhost"
ALLOWED_ORIGINS="${ALLOWED_ORIGINS},http://$HOSTNAME,https://$HOSTNAME"
ALLOWED_ORIGINS="${ALLOWED_ORIGINS},http://$HOSTNAME_LOWER,https://$HOSTNAME_LOWER"
if [ "$HOSTNAME" != "$HOSTNAME_FQDN" ]; then
    ALLOWED_ORIGINS="${ALLOWED_ORIGINS},http://$HOSTNAME_FQDN,https://$HOSTNAME_FQDN"
    ALLOWED_ORIGINS="${ALLOWED_ORIGINS},http://$HOSTNAME_FQDN_LOWER,https://$HOSTNAME_FQDN_LOWER"
fi

sed -i.bak "s|ALLOWED_ORIGINS=.*|ALLOWED_ORIGINS=$ALLOWED_ORIGINS|" .env

# Update SSL certificate with correct CN
echo "🔐 Regenerating SSL certificate for $HOSTNAME..."
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout ssl/key.pem \
    -out ssl/cert.pem \
    -subj "/C=US/ST=State/L=City/O=Organization/CN=$HOSTNAME" \
    2>/dev/null

# Login to GitHub Container Registry
echo ""
echo "🔐 Logging in to GitHub Container Registry..."
echo "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" | docker login ghcr.io -u alflewerken --password-stdin

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to login to GitHub Container Registry${NC}"
    echo "The images might be private and require authentication."
    exit 1
fi

# Pull images
echo ""
echo "📥 Pulling Docker images..."
$COMPOSE_COMMAND pull

# Start services with proper order
echo ""
echo "🚀 Starting services..."

# Start database first
echo "   Starting database..."
$COMPOSE_COMMAND up -d database

# Wait for database to be ready
echo "   Waiting for database to be ready..."
sleep 10

# Load DB password from .env
DB_ROOT_PWD=$(grep "^DB_ROOT_PASSWORD=" .env | cut -d'=' -f2)

# Check if database is healthy
for i in {1..30}; do
    if $COMPOSE_COMMAND exec database mariadb -u root -p${DB_ROOT_PWD} -e "SELECT 1" &>/dev/null; then
        echo -e "${GREEN}   ✅ Database is ready${NC}"
        break
    fi
    echo "   Waiting for database... ($i/30)"
    sleep 2
done

# Start core services
echo "   Starting core services..."
$COMPOSE_COMMAND up -d backend frontend webserver

# Start optional services (continue even if they fail)
echo "   Starting optional services..."
$COMPOSE_COMMAND up -d ttyd || echo -e "${YELLOW}   ⚠️  Terminal service failed to start${NC}"
$COMPOSE_COMMAND up -d guacd guacamole-postgres guacamole || echo -e "${YELLOW}   ⚠️  Remote desktop service failed to start${NC}"

# Final check
echo ""
echo "🔍 Checking service status..."
$COMPOSE_COMMAND ps

# Check if services are actually running
BACKEND_RUNNING=$($COMPOSE_COMMAND ps | grep "appliance_backend" | grep -c "Up\|running")
WEBSERVER_RUNNING=$($COMPOSE_COMMAND ps | grep "appliance_webserver" | grep -c "Up\|running")

if [ "$BACKEND_RUNNING" -eq 1 ] && [ "$WEBSERVER_RUNNING" -eq 1 ]; then
    echo ""
    echo -e "${GREEN}✅ Installation complete!${NC}"
    echo ""
    echo "🌐 Access the dashboard at:"
    echo "   - http://localhost"
    echo "   - http://$HOSTNAME"
    echo "   - http://$HOSTNAME_LOWER"
    if [ "$HOSTNAME" != "$HOSTNAME_FQDN" ]; then
        echo "   - http://$HOSTNAME_FQDN"
        echo "   - http://$HOSTNAME_FQDN_LOWER"
    fi
    echo ""
    echo "👤 Default login:"
    echo "   Username: admin"
    echo "   Password: admin123"
    echo ""
    echo "📝 Logs: $COMPOSE_COMMAND logs -f"
    echo "🛑 Stop: $COMPOSE_COMMAND down"
else
    echo ""
    echo -e "${RED}❌ Some services failed to start properly${NC}"
    echo "Check logs with: $COMPOSE_COMMAND logs"
    exit 1
fi
