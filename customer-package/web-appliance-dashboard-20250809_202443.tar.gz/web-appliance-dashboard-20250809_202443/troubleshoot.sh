#!/bin/bash
# Troubleshooting script for Web Appliance Dashboard

echo "=== Web Appliance Dashboard Troubleshooting ==="
echo ""

# Detect Docker Compose
COMPOSE_COMMAND=""
if command -v docker-compose &> /dev/null; then
    COMPOSE_COMMAND="docker-compose"
elif docker compose version &> /dev/null 2>&1; then
    COMPOSE_COMMAND="docker compose"
fi

echo "1. Container Status:"
$COMPOSE_COMMAND ps
echo ""

echo "2. Recent Backend Logs:"
$COMPOSE_COMMAND logs --tail=20 backend
echo ""

echo "3. Database Connection Test:"
DB_ROOT_PWD=$(grep "^DB_ROOT_PASSWORD=" .env | cut -d'=' -f2)
$COMPOSE_COMMAND exec database mariadb -u root -p${DB_ROOT_PWD} -e "SELECT COUNT(*) as user_count FROM appliance_dashboard.users;" 2>&1
echo ""

echo "4. Network Connectivity:"
$COMPOSE_COMMAND exec backend ping -c 1 database || echo "Cannot reach database"
echo ""

echo "5. Port Bindings:"
netstat -tln | grep -E ":(80|443|3001|3306)\s" || ss -tln | grep -E ":(80|443|3001|3306)\s"
echo ""

echo "6. CORS Configuration:"
grep ALLOWED_ORIGINS .env
echo ""

echo "7. Backend Environment:"
$COMPOSE_COMMAND exec backend env | grep -E "(ALLOWED_ORIGINS|DB_|NODE_ENV)"
echo ""

echo "💡 Common Issues:"
echo "- Port 80/443 already in use: Change HTTP_PORT/HTTPS_PORT in .env"
echo "- Cannot connect to database: Wait for database to fully start"
echo "- Login fails: Ensure database is initialized (check logs)"
echo "- CORS errors: Check that hostname matches ALLOWED_ORIGINS"
echo "- Services not starting: Check 'docker-compose logs [service]'"
